
    <footer class="footer-bar">
         <div class="row">
          <div class="large-6 columns medium-7 columns">
            <div class="footer-menu">

              <ul class="menu">
                  <li class="menu-text menu-divider"> <a href="#"> Home </a></li>
                  <li class="menu-text menu-divider"><a href="#"> About Us </a></li>
                  <li class="menu-text menu-divider"><a href="#"> Terms & Conditions </a></li>
                  <li class="menu-text menu-divider"><a href="#"> Contact Us </a></li>
                  <li class="menu-text menu-divider"><a href="#"> Resources </a></li>
                  <li class="menu-text menu-divider"><a href="#"> FAQs </a></li>
                  <li class="menu-text"><a href="#"> Blog </a></li>
              </ul>
              
            </div>

          </div>
          <div class="large-6 columns medium-3 columns">
              <span class="copyright"> Copyright &copy; 2016 SuraImages </span>

          </div>
        </div>
  
    </footer>


    
    <script src="<?php echo base_url('/assets/registration/js/vendor/jquery.js')?>"></script>
    <script type="text/javascript" src="<?php echo base_url('/assets/registration/filer/js/jquery.filer.min.js?v=1.0.5')?>"></script>
    <script type="text/javascript" src="<?php echo base_url('/assets/registration/filer/js/custom.js?v=1.0.5')?>"></script>
    <script src="<?php echo base_url('/assets/registration/js/vendor/what-input.js')?>"></script>
    <script src="<?php echo base_url('/assets/registration/js/vendor/foundation.js')?>"></script>
    <script src="<?php echo base_url('/assets/registration/js/vendor/fontAwesome.js')?>"></script>
    <script src="<?php echo base_url('/assets/registration/js/vendor/slick.min.js')?>"></script>
    <script src="<?php echo base_url('/assets/registration/js/app.js')?>"></script> 
    <script type="text/javascript">
        $('.close').click(
            function(){
             // console.log('something');
          });
    </script>
  </body>
</html>