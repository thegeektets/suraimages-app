<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css"/>
<style type="text/css">
  @font-face {
    font-family: 'Calibri';
    font-weight: 700;
    src: url('http://clientzone.dezaritechnologies.com/sura_images/admin/assets/calibri/Calibri Bold.ttf');
  }

  @font-face {
    font-family: 'Calibri';
    font-weight: normal;
    src: url('http://clientzone.dezaritechnologies.com/sura_images/admin/assets/calibri/Calibri.ttf');
  }
  @font-face {
    font-family: 'Calibri';
    font-weight: 100;
    src: url('http://clientzone.dezaritechnologies.com/sura_images/admin/assets/calibri/calibril.ttf');
  }
  body,
  html {
    background: #fff !important;
  } 
  body {
    background: #f3f3f3 !important;
    margin: 0px auto;
    padding-left: 25px;
    padding-right: 25px;
    width: 900px;
    box-shadow: 5px 5px 5px #888888;
    margin-top: 10;
    margin-bottom: 10;
    position: relative;
    font-family: 'Calibri';
    font-weight: 300;
    font-size: 18px;
    color: #888;
  }

  .header {
    background: #262134 !important;
    margin-left: -25px;
    margin-right: -25px;
    display: block;
  }
  .body-drip {
    display: block;
    margin-top: 10px;
  }
  .logo {
    padding: 10px;
    float: left;
  }
  .logo > img {
    height: 40px;
  }
  .phone {
    margin-top: 10px;
    float: right;
    padding: 10px;
    color: #fff;
  }
  .footer {
     background: #262134 !important;
     padding: 15px;
     display: block; 
     position: absolute;
     bottom: 0px;
     left: 0px;
     width: 920px;
  }
  .copyright {
    color: #fff;
    float: right;
    font-size: 14px;
  }
  .social {
    float: right;
    color: #fff;
    font-size: 14px;
    margin-right: 10px;
  }
  .image_thumb {
      display: inline-block;
      padding: 10px;
      width: 20%;
      float: left;
  }
  .image_desc {
      display: inline-block;
      width: 60%;
      float: left;
  }
  .image_cost {
      width: 15%;
      text-align: center;
      display: inline-block;
      float: right;
  }
</style>
</head>
<container class="header">
  <div class="logo">
    <img src="http://clientzone.dezaritechnologies.com/sura_images/non_member/assets/img/sura_logo.png" alt="">
  </div>
  <div class="phone">
      <i class="fa fa-phone" aria-hidden="true"></i>
      +254 20 242 9588
  </div>
  <div style="clear: both"></div>
</container>

<container class="body-drip">

  <spacer size="16"></spacer>

  <spacer size="16"></spacer>

  <row>
    <columns>
      <h3 class="text-center"> Subject: Sale(s) notification </h3>
    </columns>
  </row>

 
  <row>
    <columns>
      <p class="text-center"> 
          Dear George,
          <br/>
          The following are the sales you have made in the last one day.
          <br/>
          <hr/>
          <row>
            <div class="image_thumb">
              <img src="http://placehold.it/150x150/663399" alt="">
            </div>
            <div class="image_desc">
              The image you appear in has been purchased. Contact your
              photographer for payment
            </div>
            <div class="image_cost">
              <strong> Amount </strong>
              <br/>
              $ 85
            </div>
          </row>
          <div style="clear: both"></div>
          <hr/>
          <row>
            <div class="image_thumb">
              <img src="http://placehold.it/150x150/663399" alt="">
            </div>
            <div class="image_desc">
              The image you appear in has been purchased. Contact your
              photographer for payment
            </div>
            <div class="image_cost">
              <strong> Amount </strong>
              <br/>
              $ 85
            </div>
          </row>
          <div style="clear: both"></div>

          <br/>
          <br/>
          
      </p>
    </columns>
  </row>

  <row class="collapsed footer">
    <columns>
      <spacer size="16"></spacer>
      
      <div class="copyright">
          Copyright &copy; 2016 Sura Images.
      </div>

      <div class="social">
          Follow Us 
          <i class="fa fa-facebook-square" aria-hidden="true"></i>
          <i class="fa fa-twitter-square" aria-hidden="true"></i>
          <i class="fa fa-youtube-square" aria-hidden="true"></i>
      </div>
    </columns>
  </row>

</container>