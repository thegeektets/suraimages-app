     <div style="clear: both"></div>
     <footer class="footer-bar">
      <div class="row">  
          <div class="large-5 columns medium-7 columns">
            <div class="footer-menu">

              <ul class="menu">
                  <li class="menu-text menu-divider"> <a href="#"> Home </a></li>
                  <li class="menu-text menu-divider"><a href="#"> About Us </a></li>
                  <li class="menu-text menu-divider"><a href="#"> Terms & Conditions </a></li>
                  <li class="menu-text menu-divider"><a href="#"> Contact Us </a></li>
                  <li class="menu-text menu-divider"><a href="#"> Resources </a></li>
                  <li class="menu-text menu-divider"><a href="#"> FAQs </a></li>
                  <li class="menu-text"><a href="#"> Blog </a></li>
              </ul>
              
            </div>

          </div>
          <div class="large-4 columns medium-3 columns">
              <span class="copyright"> Copyright &copy; 2016 SuraImages </span>

          </div>
          <div class="large-3 columns medium-2 columns">
            <div class="footer-social_media">
              <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
              <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
              <a href="#"><i class="fa fa-youtube" aria-hidden="true"></i></a>
              <a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
            </div>
          </div>


      </div>
    </footer>

    <script src="<?php echo base_url('/assets/non_member/js/vendor/jquery.js')?>"></script>
    <script src="<?php echo base_url('/assets/non_member/js/jquery.mosaicflow.js')?>"></script>    
    <script src="<?php echo base_url('/assets/non_member/js/vendor/what-input.js')?>"></script>
    <script src="<?php echo base_url('/assets/non_member/js/vendor/foundation.js')?>"></script>
    <script src="<?php echo base_url('/assets/non_member/js/vendor/slick.min.js')?>"></script>
    <script src="<?php echo base_url('/assets/non_member/js/app.js')?>"></script>
    
  </body>
</html>
