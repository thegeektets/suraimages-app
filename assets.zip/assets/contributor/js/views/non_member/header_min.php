
  <body class="inside_page_body">

    <div class="title-bar" data-responsive-toggle="main-menu" data-hide-for="medium">
      <button class="menu-icon" type="button" data-toggle> </button>
      <div class="title-bar-title">Sura Images </div>
    </div>

     <div class="top-bar" id="main-menu">
      <div class="large-12 columns">
        <div class="top-bar-left">
            <div class="home_logo">
        </div>
        </div>
        <div class="top-bar-right inside-page">
          <ul class="menu" data-responsive-menu="medium-dropdown">
            <li class="menu-text menu-divider"> <a href="<?php echo base_url('/index.php/registration/login')?>">Sign in  </a></li>
            <li class="menu-text menu-divider"><a href="#"> <a href="<?php echo base_url('/index.php/registration')?>">Register </a></li>
            <li class="menu-text"><a href="#" class="shopping_cart"> <i class="fa fa-shopping-basket" aria-hidden="true"></i> (2)</a></li>
          </ul>
        </div>
     
    </div>
  </div>
 