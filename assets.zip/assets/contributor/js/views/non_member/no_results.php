<div class = "row">
	<div class="no_results">
		<div class="home_logo result">
		</div>
		SuraImages did not find any results !
	</div>
</div>