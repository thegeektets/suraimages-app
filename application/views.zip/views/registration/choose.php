
      <div class="inside_body">
          <div class="registration_body">
              <div class="registration_message">
                 Thank you for choosing Sura Images as your
                 creative resource of choice.
              </div>
              <div class="registration_message">
                 One more step to complete your registration.
              </div>
              <div class="registration_message">
                <span style="font-style:italic"> Choose what you want to become. </span>
              </div>
            
              <div class="large-12 columns">
                <a class="button member pull-left" href="<?php echo base_url('/index.php/registration/open_member_dashboard')?>">
                  MEMBER
                </a>
                <a class="button contributor pull-right" href="<?php echo base_url('/index.php/registration/open_contributor_dashboard')?>">
                  CONTRIBUTOR
                </a>
              </div>
              <div style="clear: both"></div>

          </div>
          


      </div>
    