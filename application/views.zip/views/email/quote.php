<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css"/>
<style type="text/css">
  @font-face {
    font-family: 'Calibri';
    font-weight: 700;
    src: url('http://clientzone.dezaritechnologies.com/sura_images/admin/assets/calibri/Calibri Bold.ttf');
  }

  @font-face {
    font-family: 'Calibri';
    font-weight: normal;
    src: url('http://clientzone.dezaritechnologies.com/sura_images/admin/assets/calibri/Calibri.ttf');
  }
  @font-face {
    font-family: 'Calibri';
    font-weight: 100;
    src: url('http://clientzone.dezaritechnologies.com/sura_images/admin/assets/calibri/calibril.ttf');
  }
  body,
  html {
    background: #fff !important;
  } 
  body {
    background: #fff !important;
    margin: 0px auto;
    padding-left: 25px;
    padding-right: 25px;
    width: 900px;
    box-shadow: 5px 5px 5px #888888;
    margin-top: 10;
    margin-bottom: 10;
    position: relative;
    font-family: 'Calibri';
    font-weight: 
    font-size: 18px;
    color: #888;
  }

  .header {
    background: transparent; !important;
    margin-left: -25px;
    margin-right: -25px;
    display: block;
  }
  .body-drip {
    display: block;
    margin-top: 10px;
  }
  .logo {
    padding: 10px;
    float: left;
    width: 20%;
  }
  .logo > img {
    height: 40px;
  }
  .address{
    display: inline-block;
    width: 25%;
    float: left;
    font-size: 14px;
    color: #262134 !important;
  }
  .phone {
    margin-top: 10px;
    float: right;
    padding: 10px;
    color: #f8991c;
    width: 20%;
    font-size: 14px;
  }
  .footer {
     padding: 15px;
     display: block; 
     position: absolute;
     bottom: 0px;
     left: 0px;
     width: 920px;
     font-size: 12px;
  }
  .copyright {
    color: #fff;
    float: right;
    font-size: 14px;
  }
  .social {
    float: right;
    color: #fff;
    font-size: 14px;
    margin-right: 10px;
  }
  .image_thumb {
      display: inline-block;
      padding: 10px;
      width: 20%;
      float: left;
  }
  .image_desc {
      display: inline-block;
      width: 60%;
      float: left;
  }
  .image_cost {
      width: 15%;
      text-align: center;
      display: inline-block;
      float: right;
  }
  .quote_head {
      background: #888;
      color: #262134;
      padding-top: 2px;
      padding-bottom: 2px;
      text-align: center;
  }
  .float-left {
      float: left;
      width: 50%;
  }
  .float-right {
    width: 50%;
    float: right;
    text-align:right;
    }
</style>
</head>
<container class="header">
  <div class="logo">
    <img src="/sura_images/sura_dark.png" alt="">
  </div>
  <div class="address">
      Duplex Lower Hill <br/>
      Upper Hill Rd <br/>
      Suite 20, Upper Hill
  </div>
  <div class="address">
      P.O Box 38540-00100 <br/>
      GPO, Nairobi, Kenya <br/>
      +254 20 242 9588
  </div>
  <div class="phone">
      www.suraimages.com
      info@suraimages.com
  </div>
  <div style="clear: both"></div>
</container>

<container class="body-drip">

  <spacer size="16"></spacer>

  <spacer size="16"></spacer>

  <row>
    <div class="quote_head">
      <h3 class="text-center"> Quotation for license(s) </h3>
    </div>
  </row>

 
  <row>
    <columns>
      <p class="text-center"> 
          <div class="float-left">
            <strong>Attention:</strong> Goerge Ngechu </br>
            <strong>Phone No:</strong> 0723992233 </br>
            <strong>Email:</strong> gngechu@gmail.com </br>
            <strong>Currency:</strong> USD </br>
          </div>
          <div class="float-right">
           <strong>Date: </strong> 12 March 2016
          </div>
          <div style="clear: both"></div>
          <br/>
          <hr/>
          <row>
            <div class="image_thumb">
              <img src="http://placehold.it/150x150/663399" alt="">
            </div>
            <div class="image_desc">
              The image you appear in has been purchased. Contact your
              photographer for payment
            </div>
            <div class="image_cost">
              <strong> Amount </strong>
              <br/>
              $ 85
            </div>
          </row>
          <div style="clear: both"></div>
          <hr/>
          <row>
            <div class="image_thumb">
              <img src="http://placehold.it/150x150/663399" alt="">
            </div>
            <div class="image_desc">
              The image you appear in has been purchased. Contact your
              photographer for payment
            </div>
            <div class="image_cost">
              <strong> Amount </strong>
              <br/>
              $ 85
            </div>
          </row>
          <div style="clear: both"></div>
          <hr/>
          <row>
            <div class="float-right">
                <strong>Total Amount : </strong>$760
            </div>
          </row>
          <div style="clear: both"></div>
          <hr/>
          
          <row class="footer">
              <hr/>
              <strong>Disclaimer: </strong>This is a system generated quote that doesn't require a stamp.
          </row>

 

</container>