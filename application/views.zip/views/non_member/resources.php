<!doctype html>
<html class="no-js" lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sura Images | Resources  </title>

    <link rel="stylesheet" href="assets/css/foundation.css">
    <link rel="stylesheet" type="text/css" href="assets/css/slick.css">
    <link rel="stylesheet" type="text/css" href="assets/css/font.css">
    <link rel="stylesheet" href="assets/css/app.css">
    <link rel="stylesheet" href="assets/css/responsive.css">

    <!--Stylesheets-->
    <link href="assets/filer/css/jquery.filer.css" type="text/css" rel="stylesheet" />
    <link href="assets/filer/css/themes/jquery.filer-dragdropbox-theme.css" type="text/css" rel="stylesheet" />
  </head>

  <body class="inside_page_body">

      <div class="title-bar" data-responsive-toggle="main-menu" data-hide-for="medium">
        <button class="menu-icon" type="button" data-toggle> </button>
        <div class="title-bar-title">Sura Images </div>
      </div>

      <div class="top-bar" id="main-menu">
        <div class="row">
          <div class="top-bar-left">
              <div class="home_logo">
          </div>
          </div>
          <div class="top-bar-right inside-page">
            <ul class="menu" data-responsive-menu="medium-dropdown">
                <li class="menu-text"> <a href="#">Welcome  </a></li>
                <li class="menu-text menu-divider"> <a href="#"> jane@gmail.com <i class="fa fa-caret-down" aria-hidden="true"></i>  </a></li>
                <li class="menu-text menu-divider"><a href="#"> Sign Out </a></li>
                <li class="menu-text"><a href="#" class="shopping_cart"> <i class="fa fa-shopping-basket" aria-hidden="true"></i> (2)</a></li>
            </ul>
          </div>
       </div>
      </div>

 

      <div class="inside_body">
          <div class="registration_body">
              <div class="registration_message">
                  Kindly verify your email address.
                  We’ve sent you a message to verify your address,
                  check email and click the link to continue.
                  The email has been sent to: <a href="">gngechu@gmail.com</a>
              </div>
              <div style="clear: both"></div>

          </div>
          


      </div>
    

    <footer class="inside-footer-bar">
         <div class="row">
          <div class="large-6 columns medium-7 columns">
            <div class="footer-menu">

              <ul class="menu">
                  <li class="menu-text menu-divider"> <a href="#"> Home </a></li>
                  <li class="menu-text menu-divider"><a href="#"> About Us </a></li>
                  <li class="menu-text menu-divider"><a href="#"> Terms & Conditions </a></li>
                  <li class="menu-text menu-divider"><a href="#"> Contact Us </a></li>
                  <li class="menu-text menu-divider"><a href="#"> Resources </a></li>
                  <li class="menu-text menu-divider"><a href="#"> FAQs </a></li>
                  <li class="menu-text"><a href="#"> Blog </a></li>
              </ul>
              
            </div>

          </div>
          <div class="large-6 columns medium-3 columns">
              <span class="copyright"> Copyright &copy; 2016 SuraImages </span>

          </div>
        </div>
  
    </footer>


    
    <script src="assets/js/vendor/jquery.js"></script>
    <script type="text/javascript" src="assets/filer/js/jquery.filer.min.js?v=1.0.5"></script>
    <script type="text/javascript" src="assets/filer/js/custom.js?v=1.0.5"></script>
    <script src="assets/js/vendor/what-input.js"></script>
    <script src="assets/js/vendor/foundation.js"></script>
    <script src="assets/js/vendor/fontAwesome.js"></script>
    <script src="assets/js/vendor/slick.min.js"></script>
    <script src="assets/js/app.js"></script>    
  </body>
</html>
