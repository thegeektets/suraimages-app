<!doctype html>
<html class="no-js" lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sura Images | Details </title>

    <link rel="stylesheet" href="assets/css/foundation.css">
    <link rel="stylesheet" type="text/css" href="assets/css/slick.css">
    <link rel="stylesheet" type="text/css" href="assets/css/font.css">
    <link rel="stylesheet" type="text/css" href="assets/css/calibri.css">
    <link rel="stylesheet" href="assets/css/app.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
   
  </head>
  <body class="inside_page_body">

    <div class="title-bar" data-responsive-toggle="main-menu" data-hide-for="medium">
      <button class="menu-icon" type="button" data-toggle> </button>
      <div class="title-bar-title">Sura Images </div>
    </div>

    
   <div class="top-bar" id="main-menu">
          <div class="row">
            <div class="top-bar-left">
                <div class="home_logo">
            </div>
            </div>
             <div class="top-bar-right">
                  <ul class="menu" data-responsive-menu="medium-dropdown">
                      <li class="menu-text menu-divider"> <a href="#">Sign in  </a></li>
                      <li class="menu-text"><a href="#"> Register </a></li>
                  </ul>
              </div>
           </div>
    </div>

 

  <div class="inside_body">
      <div class="row collapse">
            <div class="large-6 columns pull-left">
                    <form class="inside_search_frm">
                      <input type="text" name="search" placeholder="Forest" class="inside_search_txt">
                      <select class="inside_search_slc">
                          <option value="Images">Images</option>
                          <option value="Videos">Vidoes</option>
                          <option value="Illustrations">Illustrations</option>
                      </select>
                      <button type="submit" class="inside_search_btn">
                          <i class="fa fa-search fa-2x" aria-hidden="true" style="color: #f8991c"></i>
                      </button>
                    </form>
            </div>
       </div>
       <div class="row collapse">
            <div class="large-6 columns pull-left">
                <div class="search_display_img">
                <img src="assets/img/search_image.png" class="search_display_img">
                
                <div class="search_img_exclusive">
                   Available for purchase from 5th September, 2016
                </div>
                </div>
                <div class="similar_links pull-right">
                  <a href="search_page.html"> Download Sample Image </a> 
                </div>
                <div class="search_popup_details">

                    <div class="search_popup_title">Title 
                      <span class="pull-right">:</span>
                    </div>
                    <div class="search_popup_content">Equitorial Forest</div>

                    <div class="search_popup_title">Image ID 
                      <span class="pull-right">:</span>
                    </div>
                    <div class="search_popup_content">SuraImage-000111</div>

                    <div class="search_popup_title" >Release Information 
                      <span class="pull-right">:</span>
                    </div>
                    
                    <div class="search_popup_content">Yes</div>



                </div>
                <hr style="border-top: dotted 1px;" />
                <div class="search_popup_details">

                    <div class="search_popup_title">License Type 
                      <span class="pull-right">:</span>
                    </div>
                    <div class="search_popup_content"> Royalty Free </div>

                    <div class="search_popup_title">Image Type
                      <span class="pull-right">:</span>
                    </div>
                    <div class="search_popup_content">Creative Image</div>




                </div>
                <hr style="border-top: dotted 1px;" />
                <div class="search_popup_details">

                    <div class="search_popup_title">Photographer 
                      <span class="pull-right">:</span>
                    </div>
                    <div class="search_popup_content">William Miriga Ngari</div>

                    <div class="search_popup_title">Copyrights
                      <span class="pull-right">:</span>
                    </div>
                    <div class="search_popup_content">William Miriga Ngari  </div>

                    <div class="search_popup_title" > Categories
                      <span class="pull-right">:</span>
                    </div>
                    
                    <div class="search_popup_content">Buildings/Landmarks , Outdoor , People , Infrastructure </div>

                    <div class="search_popup_title" > Keywords
                      <span class="pull-right">:</span>
                    </div>
                    
                    <div class="search_popup_content"> <a href="">Evening</a>  , <a href="">Grab</a></div>


                </div>
                <hr style="border-top: dotted 1px;" />
            </div>
            <div class="large-6 columns pull-right">
                  <hr style="border-top: solid 1px;" />
                  <ul class="accordion search_details_accordion" data-accordion>
                   
                    <li class="accordion-item search_details_accordion_item is-active " data-accordion-item>
                      
                      <a href="#" class="accordion-title">
                          <i class="fa fa-calculator" aria-hidden="true"></i>
                         View Price 
                      </a>
                      
                      <div class="accordion-content search_details_accordion_content" data-tab-content>

                            <div class="tabs-content" data-tabs-content="example-tabs">
                                
                                  <div class="search_price_exclusive">
                                     Sorry. This image has exlusive license assigned to it. It will be available for purchase from 5th September, 2016
                                  </div>
                               
                            </div>
                      </div>
                    </li>
                    <hr style="border-top: solid 1px;" />
                    
                    <li class="accordion-item search_details_accordion_item" data-accordion-item>
                      
                      <a href="#" class="accordion-title">
                        <i class="fa fa-download" aria-hidden="true"></i>
                         Download History
                      </a>
                      <div class="accordion-content search_details_accordion_content" data-tab-content>
                        <p>This shows the number of times this content has been downloaded within speci ed
region and sub region to help licensee understand the distribution of the content.</p>
                              <ul class="tabs" data-tabs id="example-tabs">
                                <span class="">
                                    <li class="tabs-title is-active"><a href="#africa" aria-selected="true">Africa (18)</a></li>
                                    <li class="tabs-title"><a href="#europe">Europe(0)</a></li>
                                    <li class="tabs-title"><a href="#n.america">N.America(0)</a></li>
                                    <li class="tabs-title"><a href="#s.america">S.America(0)</a></li>
                                    <li class="tabs-title"><a href="#asia">Asia(0)</a></li>
                                </span>
                              </ul>

                              <div class="tabs-content" data-tabs-content="example-tabs">
                                <div class="tabs-panel is-active" id="africa">
                                      <ul>
                                          <li>Kenya (5)</li>
                                          <li>Kenya (12)</li>
                                          <li>Uganda (1)</li>
                                      </ul>
                                </div>
                                <div class="tabs-panel" id="europe">
                                </div>
                                <div class="tabs-panel" id="n.america">
                                </div>
                                <div class="tabs-panel" id="s.america">
                                </div>
                                <div class="tabs-panel" id="asia">
                                </div>
                              </div>
                        </div>
                             
                    </li>
                       <hr style="border-top: solid 1px;" />
                  
                    <li class="accordion-item search_details_accordion_item" data-accordion-item>
                      <a href="#" class="accordion-title">
                        <i class="fa fa-clone" aria-hidden="true"></i>
                          See more images like this
                      </a>
                    </li>
                    
                    <!-- ... -->
                  </ul>
                  
            </div>
            <div class="row collapse">
                  <div class="similar_links">
                    Same Shoot | <a href="search_page.html"> View All </a> 
                  </div>
                  <div class="large-11 columns similar-images">
                      <div class="large-2 columns">
                        <img src="assets/img/search_image.png" class="search_img">
                      </div>
                      <div class="large-2 columns">
                        <img src="assets/img/search_image.png" class="search_img">
                      </div>
                      <div class="large-2 columns">
                        <img src="assets/img/search_image.png" class="search_img">

                      </div>
                      <div class="large-2 columns">
                        <img src="assets/img/search_image.png" class="search_img">

                      </div>
                      <div class="large-2 columns">
                        <img src="assets/img/search_image.png" class="search_img">

                      </div>
                      <div class="large-2 columns">
                        <img src="assets/img/search_image.png" class="search_img">

                      </div>
                      <div class="large-2 columns">
                        <img src="assets/img/search_image.png" class="search_img">

                      </div>
                      <div class="large-2 columns">
                        <img src="assets/img/search_image.png" class="search_img">

                      </div>
                  </div>  
            </div>
            
       </div>

    <footer class="inside-footer-bar">
         <div class="row collapse">
          <div class="large-6 columns medium-7 columns">
            <div class="footer-menu">

              <ul class="menu">
                  <li class="menu-text menu-divider"> <a href="#"> Home </a></li>
                  <li class="menu-text menu-divider"><a href="#"> About Us </a></li>
                  <li class="menu-text menu-divider"><a href="#"> Terms & Conditions </a></li>
                  <li class="menu-text menu-divider"><a href="#"> Contact Us </a></li>
                  <li class="menu-text menu-divider"><a href="#"> Resources </a></li>
                  <li class="menu-text menu-divider"><a href="#"> FAQs </a></li>
                  <li class="menu-text"><a href="#"> Blog </a></li>
              </ul>
              
            </div>

          </div>
          <div class="large-6 columns medium-3 columns">
              <span class="copyright"> Copyright &copy; 2016 SuraImages </span>

          </div>
        </div>
  
    </footer>


    
    <script src="assets/js/vendor/jquery.js"></script>
    <script src="assets/js/vendor/what-input.js"></script>
    <script src="assets/js/vendor/foundation.js"></script>
    <script src="assets/js/vendor/fontAwesome.js"></script>
    <script src="assets/js/vendor/slick.min.js"></script>
    <script src="assets/js/app.js"></script>    
  </body>
</html>
